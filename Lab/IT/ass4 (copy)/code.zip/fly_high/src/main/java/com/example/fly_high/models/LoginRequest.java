package com.example.fly_high.models;


import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class LoginRequest {
    public String username;
    public String password;
}
