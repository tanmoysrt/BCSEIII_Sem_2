module.exports = {
    'API_BASE_URL': 'http://localhost:8080'
}