export default function OffersTab(){
    return (
    <div className="bg-cred text-white my-4 p-2 rounded-md">
        <marquee>Hi bro how are you all get ready sey</marquee>
    </div>
    );
}