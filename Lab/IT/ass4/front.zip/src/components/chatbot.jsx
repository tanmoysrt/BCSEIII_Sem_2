import {useState} from "react";
import {Widget} from "react-chat-widget";

export default function ChatBot(){
    return (
        <>
            Bye bye
        </>
    );

}