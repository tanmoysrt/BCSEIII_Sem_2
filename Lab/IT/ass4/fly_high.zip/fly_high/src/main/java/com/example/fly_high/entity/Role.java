package com.example.fly_high.entity;

public enum Role {
    STAFF,
    ADMIN
}
